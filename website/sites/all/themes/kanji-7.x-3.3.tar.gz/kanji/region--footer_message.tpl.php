<?php // For the footer message, only $content is needed ?>
<?php print $content ?>
