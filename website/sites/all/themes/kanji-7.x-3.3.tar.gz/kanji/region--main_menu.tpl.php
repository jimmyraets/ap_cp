<?php // For main_menu only content is needed  ?>
<?php print $content; ?>
