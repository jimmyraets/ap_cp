Installation
===========
1. Download the module to sites/all/modules/features.
2. Once you have the dependent contributed modules, enable it.
   Important: make sure you have downloaded the latest dev versions of views, ctools, calendar and date
   modules.
3. Create some events at Add Content > Event.
4. Go to /events and see your events listed. Click on the links at the calendar block to see how they get
   filtered.

Related links
============
  * For project description, refer to http://drupal.org/sandbox/juampy/1250668.
  * For step by step guide to recreate what this feature contains, read http://drupal.org/node/1250714
